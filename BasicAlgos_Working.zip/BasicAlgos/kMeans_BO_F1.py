from sklearn.cluster import KMeans
from functions import precompute_fx
from functions import ft_F1
from bayes_opt import BayesianOptimization
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier as RF
from sklearn.metrics import accuracy_score, f1_score
import warnings
warnings.filterwarnings("ignore")


def KMeans_F1(k, X_train):
    kmeans = KMeans(n_clusters=k, init="k-means++", n_init=10, max_iter= 300, random_state=42)
    y_kmeans = kmeans.fit_predict(X_train)

    # For simplicity, create pandas dataframe to store all pred + true values:
    df = pd.DataFrame(X_train)
    df['targets'] = y_train
    df['y_kmeans'] = y_kmeans
    df_clust = []
    for clust_id in range(k):
        temp = df[df['y_kmeans']==clust_id]
        temp_X = temp.iloc[:,:X_train.shape[1]]
        X_ = temp_X.to_numpy()
        y_ = temp.iloc[:,X_train.shape[1]].to_numpy()
        # print(f'clust_id: {clust_id} for k = {k}; list has {len(X_)} values')
        precomp_fx = precompute_fx(X_, y_)
        cls_index = precomp_fx['cls_index']
        cls_n_ex = precomp_fx['cls_n_ex']

        F1 = ft_F1(X_, cls_index, cls_n_ex)
        df_clust.append(F1)

    return np.mean(df_clust)

def Optimize_kmeans(X_train, y_train):
    #Apply Bayesian Optimization to K-Means
    def kmeans_f1(k):
        return KMeans_F1(k=int(k), X_train=X_train)
    n = np.unique(y_train)
    optimizer = BayesianOptimization(
        f=kmeans_f1,
        pbounds={
            "k": (2, len(n)-1),
        },
        ptypes={'k': int},
        random_state=42,
        verbose=2
    )
    optimizer.maximize(n_iter=5)

    return int(optimizer.max['params']['k'])


# Import training and testing data from Imbalance Data Generator project output CSV file:
df_train = pd.read_csv('./Training_Data.csv')
df_test = pd.read_csv('./Testing_Data.csv')

y_train = df_train['target'].to_numpy()
X_train = df_train.drop(columns=['index','target'])
X_train = X_train.to_numpy()

y_test = df_test['target'].to_numpy()
X_test = df_test.drop(columns=['index','target'])
X_test = X_test.to_numpy()

k_opt = Optimize_kmeans(X_train, y_train)
print()
print('Optimum k value is: k = ', k_opt)

print('-------------------------------------------------------------------------------------------------')
# Cluster as per the optimum k-value:
print(f'Applying clustering with k = {k_opt} on training data..')
kmeans = KMeans(n_clusters=k_opt, init="k-means++", n_init=10, max_iter= 300, random_state=42)
y_kmeans = kmeans.fit_predict(X_train)

df_kmeans_bo_f1 = pd.DataFrame()
df_kmeans_bo_f1['Cluster_ID'] = y_kmeans
df_kmeans_bo_f1.to_csv('./Training_Data_ARI_KMeans.csv', index=False)

print()
print(f'{k_opt} clusters successfully created')

print('-------------------------------------------------------------------------------------------------')
print('Starting to train Random Forest on each cluster formed..')

# Train Random Forest on each cluster formed:
# For simplicity, create pandas dataframe to store all pred + true values:
# Store all RF classifiers into list and also store all cluster centers into separate list.

df = pd.DataFrame(X_train)
df['targets'] = y_train
df['y_kmeans'] = y_kmeans
rf_classifiers = []
cluster_centers = []
for clust_id in range(k_opt):
    print(f'Training Random Forest on cluster {clust_id}')
    temp = df[df['y_kmeans']==clust_id]
    temp_X = temp.iloc[:,:X_train.shape[1]]
    X_ = temp_X.to_numpy()
    y_ = temp.iloc[:,X_train.shape[1]].to_numpy()
    rf = RF(random_state=42)
    clf = rf.fit(X_, y_)
    rf_classifiers.append(clf)
    X_center = np.mean(X_, axis=0)
    cluster_centers.append(X_center)

# Consider 'X_test' data and allocate each data point to nearest cluster center, store predictions and targets in dataframe:
print('--------------------------------------------------------------------------------------------------')
print('Allocating data points in X_test to nearest cluster and predicting the result using classifier trained on it..')
df_test = pd.DataFrame(X_test)
df_test['y_true'] = y_test
y_pred = []
for point in X_test:
    dist = []
    for i in cluster_centers:
        dist.append(np.linalg.norm(point - i))
    near_clust_id = np.argmin(dist)
    # print('Nearest Cluster ID: ', near_clust_id)
    res = rf_classifiers[near_clust_id].predict([point])
    y_pred.append(res[0])
df_test['y_pred'] = y_pred
print()
print('Classifier successfully predicted the test data. Showing the overall result in a dataframe:')

# 'y_true' is the true target and 'y_pred' is the predicted one using classifier trained on each cluster.

print('--------------------------------------------------------------------------------------------------')
print(df_test.head(20))
print()
print('Accuracy of predicted score is: ',accuracy_score(df_test['y_true'],df_test['y_pred']))
print()
print('F1-score of predicted score is: ',f1_score(df_test['y_true'],df_test['y_pred'],average='weighted'))

df_res = pd.DataFrame(columns=['DCM', 'Clustering_Method', 'Opt-k', 'Accuracy', 'F1-score'])
df_res.loc[0,'DCM'] = "F1-Measure"
df_res.loc[0,'Clustering_Method'] = "K-Means"
df_res.loc[0,'Opt-k'] = k_opt
df_res.loc[0,'Accuracy'] = accuracy_score(df_test['y_true'],df_test['y_pred'])
df_res.loc[0,'F1-score'] = f1_score(df_test['y_true'],df_test['y_pred'],average='weighted')
df_res.to_csv('./Results.csv', header=True, index=False)